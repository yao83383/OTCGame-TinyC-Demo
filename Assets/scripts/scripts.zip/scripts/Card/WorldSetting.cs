using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldSetting : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //void SetupMSAA()
    //{
    //    var qualitySettings = new UnityEngine.Rendering.QualitySettings();
    //    var currentLevel = qualitySettings.antiAliasing;
    //
    //    // ������Ҫ���ò�ͬ��MSAA��������4x
    //    qualitySettings.antiAliasing = 4;
    //
    //    // Ӧ������
    //    UnityEngine.Rendering.QualitySettings.SetDirty();
    //}
}

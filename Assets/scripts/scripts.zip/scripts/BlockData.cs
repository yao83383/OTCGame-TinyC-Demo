using System;

[Serializable]
public class BlockData
{
	public int kind;

	public int land;

	public int level;

	public int number;

	public int speed;

	public int x;

	public int y;
}

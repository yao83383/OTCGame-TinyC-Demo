using System;

[Serializable]
public class WonderName
{
	public string name;

	public string english;
}

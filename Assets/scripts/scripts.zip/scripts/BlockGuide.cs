using System;

[Serializable]
public class BlockGuide
{
	public string name;

	public int number;

	public string discription;

	public string englishName;

	public string englishDis;
}

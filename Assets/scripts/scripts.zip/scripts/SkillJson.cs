using System;

[Serializable]
public class SkillJson
{
	public string name;

	public int number;

	public int cost;

	public int cost1;

	public int cost2;

	public int cost3;

	public int cost4;

	public int hardCost;

	public string discription;

	public string english;

	public string englishDiscription;
}

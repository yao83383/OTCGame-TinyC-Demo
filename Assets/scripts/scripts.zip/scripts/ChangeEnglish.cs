using UnityEngine;

public class ChangeEnglish : MonoBehaviour
{
	public World world;

	public bool inBattle;

	private void Start()
	{
	}

	private void Update()
	{
	}

	public void ChangeEsc()
	{
	}

	public void ChangeMenu()
	{
	}

	public void ChangeBattle()
	{
	}
}

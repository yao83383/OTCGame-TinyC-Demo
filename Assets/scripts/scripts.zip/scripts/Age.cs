using System;

[Serializable]
public class Age
{
	public string name;

	public int number;

	public string discription1;

	public string discription2;

	public string englishName;

	public string englishDis1;

	public string englishDis2;
}

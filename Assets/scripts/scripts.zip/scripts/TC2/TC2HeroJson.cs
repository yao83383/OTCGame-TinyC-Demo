using System;

[Serializable]
public class TC2HeroJson
{
	public string name;

	public int number;

	public string discription;

	public int startAge;

	public int endAge;

	public string englishName;

	public string englishDis;
}

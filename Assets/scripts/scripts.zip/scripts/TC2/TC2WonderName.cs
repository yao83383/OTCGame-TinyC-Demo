using System;

[Serializable]
public class TC2WonderName
{
	public string name;

	public string english;
}

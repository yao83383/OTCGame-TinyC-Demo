using System;

[Serializable]
public class TC2BlockSlotJson
{
    public int x;
    public int y;

    public bool IsAvailable;
}
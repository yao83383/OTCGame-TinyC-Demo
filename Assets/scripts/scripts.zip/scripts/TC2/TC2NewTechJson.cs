using System;

[Serializable]
public class TC2NewTechJson
{
	public string name;

	public int number;

	public int culture;

	public string discription;

	public int age;

	public string englishName;

	public string englishDis;
}

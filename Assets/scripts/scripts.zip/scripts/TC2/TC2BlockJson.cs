using System;

[Serializable]
public class TC2BlockJson
{
    public int x;
    public int y;

    public string kindName;
    public int level;
}